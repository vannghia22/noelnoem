# GEMA · UGC 30 giây
## Style Prompt
UGC đời thường, ấm áp theo ảnh tham chiếu: tường đen, ánh đèn vàng, nhân vật và sản phẩm nguyên bản. Dùng ảnh gốc với crop và chuyển động máy quay ảo; không dựng giả thao tác gấp, thay công tắc hoặc chuyển động miệng từ một ảnh duy nhất. Nhịp thay khung 2–4 giây, crossfade nhanh 0.15–0.25 giây, hook punch-in, CTA bounce nhẹ.
## Colors
- #181512: nền đen ấm
- #FFFFFF: phụ đề
- #FFD65A: từ khóa và CTA theo yêu cầu
- #B6B3AE: màu xám bạc tham chiếu, không phủ màu sản phẩm
## Typography
Be Vietnam Pro 800 cho phụ đề và headline; 400 cho chú thích. Phụ đề tối đa hai dòng, tránh mặt và sản phẩm, chừa vùng giao diện TikTok bên phải và phía dưới.
## What NOT to Do
- Không sửa khuôn mặt, logo, hình dáng hay màu sản phẩm.
- Không giả footage thao tác khi không có ảnh/video tương ứng.
- Không lip-sync ảnh tĩnh.
- Không tuyên bố 3000W là công suất đã kiểm chứng; không đưa giá cố định hay đánh giá giả.
- Không render video placeholder như sản phẩm hoàn chỉnh.
