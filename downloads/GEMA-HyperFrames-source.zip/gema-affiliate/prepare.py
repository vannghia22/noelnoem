import json, subprocess, wave
from pathlib import Path
import numpy as np
import soundfile as sf
import sherpa_onnx
root=Path(__file__).parent
m=Path('/workspace/gema-tools/vits-piper-vi_VN-vais1000-medium')
print(list(m.iterdir()))
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'vi_VN-vais1000-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=3,debug=False))
tts=sherpa_onnx.OfflineTts(config)
sections=[(0,3,['Ủa, máy sấy này','gấp gọn được luôn nè!']),(3,5,['Đây là máy sấy GEMA,','màu xám nhìn tối giản','mà cũng khá sang.']),(8,7,['Tay cầm có thể gập lại,','nên cất trong tủ','hay mang đi chơi','cũng đỡ chiếm chỗ.']),(15,7,['Máy có chế độ nóng và lạnh','để lựa chọn tùy nhu cầu,','phía dưới còn có móc treo nữa.']),(22,4,['Bạn nào phòng nhỏ','hoặc hay đi xa','có thể tham khảo mẫu này.']),(26,4,['Giá hiện tại và thông tin chi tiết','mình để ở giỏ hàng nha!'])]
sr=24000;master=np.zeros(30*sr,dtype=np.float32);caps=[]
for i,(start,dur,phrases) in enumerate(sections):
 text=' '.join(phrases).replace('GEMA','Gê ma')
 a=tts.generate(text,sid=0,speed=1.0)
 raw=root/'assets'/f'voice-{i}-raw.wav';out=root/'assets'/f'voice-{i}.wav'
 sf.write(raw,a.samples,a.sample_rate)
 rawdur=len(a.samples)/a.sample_rate;target=dur-.22;ratio=rawdur/target
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',f'atempo={ratio},loudnorm=I=-16:TP=-1.5:LRA=7','-ar',str(sr),str(out)],check=True)
 data,_=sf.read(out);offset=int((start+.08)*sr);master[offset:offset+min(len(data),len(master)-offset)]+=data[:len(master)-offset]
 weights=[len(p.split()) for p in phrases];t=start+.08
 for p,w in zip(phrases,weights):
  end=t+target*w/sum(weights);caps.append({'start':round(t,3),'end':round(end,3),'text':p});t=end
 print(i,'raw',rawdur,'target',target,'tempo',ratio,flush=True)
sf.write(root/'assets'/'narration.wav',master,sr)
(root/'captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
# Original low-volume instrumental: warm soft keys, bass pulse, light percussion.
t=np.arange(sr*30)/sr;music=np.zeros_like(t)
for beat in range(60):
 s=beat*.5;env=np.exp(-np.maximum(t-s,0)*13)*(t>=s);music+=.025*np.sin(2*np.pi*65*(t-s))*env
for bar,chord in enumerate([(220,261.63,329.63),(174.61,220,261.63),(196,246.94,293.66),(164.81,196,246.94)]*2):
 s=bar*4
 for f in chord:
  local=t-s;env=np.where(local>=0,(1-np.exp(-np.maximum(local,0)*8))*np.exp(-np.maximum(local,0)*.9),0)
  music+=.014*np.sin(2*np.pi*f*local)*env
music*=np.minimum(t/.4,1)*np.minimum((30-t)/.6,1)
sfx=np.zeros_like(t)
for start,freq in [(.12,660),(26.2,1100)]:
 local=t-start;env=(local>=0)*np.exp(-np.maximum(local,0)*35);sfx+=.12*np.sin(2*np.pi*freq*local)*env
sf.write(root/'assets'/'soundtrack.wav',np.clip(master+music+sfx,-.98,.98),sr)
