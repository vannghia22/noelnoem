# GEMA TikTok Affiliate · 30 seconds

HyperFrames project, 1080×1920, 30 fps. Source image supplied by the user, kept unchanged in assets/reference/. The edit uses virtual camera crops; it does not simulate folding, lip-sync, or real hand gestures. Product feature statements follow the user's supplied brief; no independently verified wattage or price is stated.

## Re-render
Node >=22, FFmpeg, Chromium. If automatic browser discovery fails, set HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium (or your installed Chromium path).

npm run check
npm run render -- --output renders/GEMA-TikTok-30s.mp4 --fps 30 --quality high --workers 2

The prepared machine runs these with npm_config_cache=/workspace/.npm and HOME=/workspace/browser-home for its Chromium proxy trust store. All final media, fonts and GSAP are local and included. No API key is required to re-render.

index.html is the editable composition. build.py rebuilds the HTML using captions.json. prepare.py documents voice/music synthesis; changing narration requires sherpa-onnx==1.12.40, numpy, soundfile and the external model below. Existing WAV assets are included, so synthesis is not required to re-render.

## Audio and credits
Vietnamese synthetic narration: Piper vi_VN-vais1000-medium via sherpa-onnx. Dataset/model card credits: VAIS-1000 Vietnamese Speech Synthesis Corpus, CC BY 4.0, https://ieee-dataport.org/documents/vais-1000-vietnamese-speech-synthesis-corpus ; model distributed at https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-vi_VN-vais1000-medium.tar.bz2 . Voice is synthetic, not a clone of the pictured person; age cannot be verified. Phrase-level captions are timed to the six synthesized narration sections, not a forced alignment.
Background music and pop/click effects are generated instrumentally by prepare.py for this edit; no third-party song is used.
Be Vietnam Pro: https://github.com/bettergui/BeVietnamPro (SIL Open Font License). GSAP 3.14.2: https://gsap.com/standard-license/ .
