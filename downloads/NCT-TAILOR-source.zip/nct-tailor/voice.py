from pathlib import Path
import sherpa_onnx,soundfile as sf,numpy as np,subprocess
p=Path(__file__).parent;m=Path('/workspace/gema-tools/vits-piper-vi_VN-vais1000-medium')
c=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(next(m.glob('*.onnx'))),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=2))
t=sherpa_onnx.OfflineTts(c);sr=48000;master=np.zeros(sr*10)
for i,(text,start,dur) in enumerate([('En xi ti. Tây lờ.',1.1,2.6),('Kiến tạo phong thái.',4.5,2.7)]):
 a=t.generate(text,sid=0,speed=.85);sf.write(p/'assets'/f'raw{i}.wav',a.samples,a.sample_rate);ratio=(len(a.samples)/a.sample_rate)/dur
 # Pitch lowered two semitones without altering timing; slow, measured phrasing.
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'assets'/f'raw{i}.wav'),'-af',f'rubberband=tempo={ratio}:pitch=0.76,highpass=f=65,equalizer=f=160:t=q:w=1:g=2,loudnorm=I=-17:TP=-2:LRA=8','-ar',str(sr),str(p/'assets'/f'voice{i}.wav')],check=True)
 x,_=sf.read(p/'assets'/f'voice{i}.wav');n=min(len(x),len(master)-int(start*sr));master[int(start*sr):int(start*sr)+n]+=x[:n]
 print(text,len(a.samples)/a.sample_rate,flush=True)
x=np.arange(sr*10)/sr;bed=np.zeros(len(x))
for start,notes in [(0,[73.416,110,146.832,174.614]),(4,[65.406,98,130.81,164.814]),(7,[73.416,110,146.832,174.614])]:
 local=x-start;env=np.where(local>=0,(1-np.exp(-np.maximum(local,0)*2))*np.exp(-np.maximum(local,0)*.55),0)
 for f in notes:bed+=.013*(np.sin(2*np.pi*f*local)+.2*np.sin(4*np.pi*f*local))*env
bed*=np.minimum(x/.5,1)*np.minimum((10-x)/1.2,1)
sf.write(p/'assets'/'mix.wav',np.clip(master+bed,-.98,.98),sr)
