# NCT.TAILOR
## Style Prompt
Black and white luxury brand sting, inspired by the user image. White expressive brush brand lettering, elegant handwritten Vietnamese slogan. Slow reveal, deliberate pause between brand and slogan, restrained ambient music. Rebuild editable lettering from reference text; the original raster upload is not available as a local asset.
## Colors
#000000 background; #FFFFFF brand and slogan; #BDBDBD decorative rule.
## Typography
Permanent Marker for NCT.TAILOR, Dancing Script 700 with Vietnamese glyphs for Kiến Tạo Phong Thái.
## What NOT to Do
No gold, invented tagline, product promises, extra CTA, energetic effects or rapid cuts. Preserve exact name and slogan spelling.
