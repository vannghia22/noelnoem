# NCT.TAILOR — Kiến Tạo Phong Thái
10-second, 1920×1080, 30fps HyperFrames brand sting.
Lettering is recreated from the user's reference text, not an exact raster reproduction of the uploaded logo.
Spoken line: “NCT Tailor. Kiến tạo phong thái.” The acronym is phoneticized as “En xi ti”.
Synthetic Vietnamese male-style narration uses Piper vi_VN-vais1000-medium via sherpa-onnx, with slower timing and a small pitch adjustment. Music is an original synthesized ambient chord bed.
Model source: https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-vi_VN-vais1000-medium.tar.bz2 . VAIS-1000 corpus attribution: https://ieee-dataport.org/documents/vais-1000-vietnamese-speech-synthesis-corpus (CC BY 4.0). Fonts: Permanent Marker (Apache 2.0), Dancing Script (SIL OFL). GSAP standard license.
Render: HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npm run render -- --output renders/NCT-TAILOR-Kien-Tao-Phong-Thai.mp4 --fps 30 --quality high
